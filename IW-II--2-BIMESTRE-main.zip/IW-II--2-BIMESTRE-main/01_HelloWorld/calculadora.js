var SomarFunc = require("./Modulos/somar")
var SubtrairFunc = require("./Modulos/subtrair")
var MultiplicarFunc = require("./Modulos/multiplicar")
var DividirFunc = require("./Modulos/dividir")

console.log("A soma é" , SomarFunc(10,8))
console.log("A subtração é" , SubtrairFunc(10,8))
console.log("A multiplicação é" , MultiplicarFunc(10,8))
console.log("A divisão é" , DividirFunc(10,8))