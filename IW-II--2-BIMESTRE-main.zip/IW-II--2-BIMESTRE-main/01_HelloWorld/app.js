console.log("Hello World!")

var n1 = 16
var n2 = 8

function somar (a,b){
    return a + b 
}

console.log("A soma é" , somar (n1,n2))