var dividir = function(a,b){
    return a / b 
}

module.exports = dividir
