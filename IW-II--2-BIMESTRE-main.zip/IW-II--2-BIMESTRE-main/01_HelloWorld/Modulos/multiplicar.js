
var multiplicar = function(a,b){
    return a * b 
}

module.exports = multiplicar