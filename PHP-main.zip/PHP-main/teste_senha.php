<?php
    $senha = "1234";

    $senha_cripto = md5($senha);
    echo $senha_cripto;

?>
